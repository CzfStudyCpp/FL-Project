# README
## 关于超神经 Hyper.AI
超神经 Hyper.AI（https://hyper.ai）是科技实验媒体，专注报道人工智能与其适用场景。致力于推动中文领域对机器智能的认知与普及，探讨机器智能的对社会的影响。超神经为提高科研效率，提供大陆范围内最快最全的公开数据集下载节点、人工智能百科词条等多个产品，服务产业相关从业者和科研院所的师生。

## 关于数据集
- 数据集名称：Book-Crossing
- 发布机构：德国自由堡大学 Albert-Ludwigs-University Freiburg
- 网址：http://www2.informatik.uni-freiburg.de/~cziegler/BX/
- 大小：0.0506 GB
- 简介：Book-Crossing数据集是来自 Book-Crossing 社区，278,858 位用户提供的约 271,379 本书的 1,149,780 个评分组成的数据集。Book-Crossing数据集包括3个表。
BX-用户
包含用户。请注意，用户ID（User-ID）已被匿名化并映射到整数。提供人口统计数据（“位置”，“年龄”）（如果有）。否则，这些字段包含NULL值。
BX-书籍
书籍由各自的ISBN标识。已从数据集中删除无效的ISBN。此外，还提供了一些基于内容的信息（“Book-Title”，“Book-Author”，“Year-Of-Publication”，“Publisher”），这些信息是从Amazon Web Services获得的。请注意，如果有多位作者，则仅提供第一个作者。还给出了链接到封面图像的URL，以三种不同的形式出现（“Image-URL-S，Image-URL-M，Image-URL-L`），即小，中，大。这些URL指向Amazon网站。
BX-书本评级
包含图书评分信息。评级（“账面评级”）要么是明确的，要么是1-10的表示（更高的值表示更高的评价），要么是隐含的，用0表示。
该数据集于2005年由德国自由堡大学发布，相关论文为Improving Recommendation Lists Through Topic Diversification。
